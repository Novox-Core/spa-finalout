import React, { useState, useEffect, useRef } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Users,
  Sliders,
  CalendarDays,
  RotateCcw,
  Settings,
  Calendar,
  XSquare,
  Tag,
  DollarSign,
} from "lucide-react";

import "./Selectcalander.css";
// import "./modern-booking-modal.css";
import { Base_url } from '../Service/Base_url';

const CustomCalendar = ({ isVisible, onClose, onDateSelect, selectedDate }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const calendarRef = useRef();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (calendarRef.current && !calendarRef.current.contains(e.target)) {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isVisible, onClose]);

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + direction);
    setCurrentDate(newDate);
  };

  const handleDateClick = (day, monthOffset = 0) => {
    const selectedDateObj = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + monthOffset,
      day
    );
    onDateSelect(selectedDateObj);
    onClose();
  };

  const handleWeekSelect = (weeks) => {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + weeks * 7);
    onDateSelect(futureDate);
    onClose();
  };

  const renderMonth = (monthOffset = 0) => {
    const displayDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + monthOffset,
      1
    );
    const daysInMonth = getDaysInMonth(displayDate);
    const firstDay = getFirstDayOfMonth(displayDate);
    const today = new Date();
    const isCurrentMonth =
      displayDate.getMonth() === today.getMonth() &&
      displayDate.getFullYear() === today.getFullYear();

    const days = [];

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="calendar-day empty"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = isCurrentMonth && day === today.getDate();
      const isSelected =
        selectedDate &&
        selectedDate.getDate() === day &&
        selectedDate.getMonth() === displayDate.getMonth() &&
        selectedDate.getFullYear() === displayDate.getFullYear();

      days.push(
        <div
          key={day}
          className={`calendar-day ${isToday ? "today" : ""} ${
            isSelected ? "selected" : ""
          }`}
          onClick={() => handleDateClick(day, monthOffset)}
        >
          {day}
        </div>
      );
    }

    return (
      <div className="calendar-month">
        <div className="calendar-month-header">
          <h3>
            {monthNames[displayDate.getMonth()]} {displayDate.getFullYear()}
          </h3>
        </div>
        <div className="calendar-weekdays">
          {dayNames.map((day) => (
            <div key={day} className="calendar-weekday">
              {day}
            </div>
          ))}
        </div>
        <div className="calendar-days">{days}</div>
      </div>
    );
  };

  if (!isVisible) return null;

  return (
    <div className="calendar-overlay">
      <div className="custom-calendar" ref={calendarRef}>
        <div className="calendar-header">
          <button
            className="calendar-nav-btn"
            onClick={() => navigateMonth(-1)}
          >
            <ChevronLeft size={20} />
          </button>
          <button className="calendar-nav-btn" onClick={() => navigateMonth(1)}>
            <ChevronRight size={20} />
          </button>
        </div>

        <div className="calendar-months">
          {renderMonth(0)}
          {renderMonth(1)}
        </div>

        <div className="calendar-quick-select">
          <button
            className="quick-select-btn"
            onClick={() => handleWeekSelect(1)}
          >
            In 1 week
          </button>
          <button
            className="quick-select-btn"
            onClick={() => handleWeekSelect(2)}
          >
            In 2 weeks
          </button>
          <button
            className="quick-select-btn"
            onClick={() => handleWeekSelect(3)}
          >
            In 3 weeks
          </button>
          <button
            className="quick-select-btn"
            onClick={() => handleWeekSelect(4)}
          >
            In 4 weeks
          </button>
          <button
            className="quick-select-btn"
            onClick={() => handleWeekSelect(5)}
          >
            In 5 weeks
          </button>
          <div className="more-options">
            <button className="quick-select-btn">More ▾</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Team selection component
const TeamSelection = ({
  isVisible,
  onClose,
  staffList,
  selectedStaff,
  onStaffToggle,
}) => {
  const teamRef = useRef();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (teamRef.current && !teamRef.current.contains(e.target)) {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  return (
    <div className="team-selection-overlay">
      <div className="team-selection-panel" ref={teamRef}>
        <div className="team-selection-header">
          <div className="team-option">
            <Users size={18} />
            <span>Scheduled team</span>
          </div>
          <div className="team-option">
            <Users size={18} />
            <span>All team</span>
          </div>
        </div>

        <div className="team-members-section">
          <div className="team-members-header">
            <h3>Team members</h3>
            <button className="clear-all-btn">Clear all</button>
          </div>

          <div className="team-members-list">
            {staffList.map((staff, index) => (
              <div key={index} className="team-member-item">
                <div className="team-member-checkbox">
                  <input
                    type="checkbox"
                    id={`staff-${index}`}
                    checked={selectedStaff.includes(index)}
                    onChange={() => onStaffToggle(index)}
                  />
                  <label htmlFor={`staff-${index}`} className="checkbox-label">
                    <div className="checkbox-custom"></div>
                  </label>
                </div>
                <div className="team-member-info">
                  <div className="team-member-avatar">
                    {staff.profileImage ? (
                      <img
                        src={staff.profileImage}
                        alt={staff.name}
                        className="avatar-image"
                      />
                    ) : (
                      <div
                        className="avatar-placeholder"
                        style={{ backgroundColor: staff.color }}
                      >
                        <span className="avatar-text">{staff.avatar}</span>
                      </div>
                    )}
                  </div>
                  <span className="team-member-name">{staff.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Color palette for staff avatars
const staffColors = [
  "#f3e8ff", "#fef3e2", "#f0f9ff", "#ffe8f0", "#e0f7ff", 
  "#f0fdf4", "#fef2f2", "#f0f4ff", "#f7fee7", "#fffbeb"
];

// Helper function to generate avatar initials
const generateAvatar = (firstName, lastName) => {
  const first = firstName ? firstName.charAt(0).toUpperCase() : '';
  const last = lastName ? lastName.charAt(0).toUpperCase() : '';
  return first + last;
};

// Generate 15-minute time slots (4 per hour) for 24 hours from 00:00 to 23:45
const generateTimeSlots = () => {
  const slots = [];
  for (let hour = 0; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += 15) {
      const timeStr = `${hour < 10 ? "0" + hour : hour}:${
        minute < 10 ? "0" + minute : minute
      }`;
      slots.push({
        time: timeStr,
        isHourStart: minute === 0,
        hour: hour,
        minute: minute,
      });
    }
  }
  return slots;
};

const timeSlots = generateTimeSlots();

const paymentMethods = [
  { value: 'cash', label: 'Cash' },
  { value: 'card', label: 'Card' },
  { value: 'online', label: 'Online' },
  { value: 'wallet', label: 'Wallet' },
  { value: 'bank-transfer', label: 'Bank Transfer' },
];

const Scheduler = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [appointments, setAppointments] = useState({});
  const [viewMode, setViewMode] = useState("Day");
  const [addDropdownOpen, setAddDropdownOpen] = useState(false);
  const [showViewDropdown, setShowViewDropdown] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [calendarVisible, setCalendarVisible] = useState(false);
  const [teamSelectionVisible, setTeamSelectionVisible] = useState(false);
  
  // Staff and bookings state
  const [staffList, setStaffList] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [staffLoading, setStaffLoading] = useState(false);
  const [bookingsLoading, setBookingsLoading] = useState(false);
  
  const [selectedStaff, setSelectedStaff] = useState([]);
  const [hoverTooltip, setHoverTooltip] = useState({
    visible: false,
    x: 0,
    y: 0,
    content: null,
  });
  const [popupData, setPopupData] = useState({
    key: "",
    x: 0,
    y: 0,
    clientName: "",
    service: "",
    paymentMethod: "",
    staffIndex: null,
  });

  const [activeWaitlistTab, setActiveWaitlistTab] = useState("upcoming");
  const [waitlistVisible, setWaitlistVisible] = useState(false);
  const [waitlistBookings, setWaitlistBookings] = useState({
    upcoming: [],
    completed: [],
    booked: []
  });

  // Booking modal state
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookingStep, setBookingStep] = useState(1);
  const [bookingServices, setBookingServices] = useState([]);
  const [bookingProfessionals, setBookingProfessionals] = useState([]);
  const [bookingTimeSlots, setBookingTimeSlots] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedProfessional, setSelectedProfessional] = useState(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const [clientInfo, setClientInfo] = useState({ name: '', email: '', phone: '' });
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingError, setBookingError] = useState(null);
  const [bookingSuccess, setBookingSuccess] = useState(null);

  // Client search and selection state
  const [existingClients, setExistingClients] = useState([]);
  const [clientSearchQuery, setClientSearchQuery] = useState('');
  const [clientSearchResults, setClientSearchResults] = useState([]);
  const [showClientSearch, setShowClientSearch] = useState(false);
  const [selectedExistingClient, setSelectedExistingClient] = useState(null);
  const [isAddingNewClient, setIsAddingNewClient] = useState(false);

  const popupRef = useRef();
  const tooltipRef = useRef();
  const waitlistRef = useRef();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    
    // Cleanup function to clear timeouts when component unmounts
    return () => {
      clearInterval(timer);
      if (window.tooltipTimeout) {
        clearTimeout(window.tooltipTimeout);
      }
      if (window.tooltipHideTimeout) {
        clearTimeout(window.tooltipHideTimeout);
      }
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (popupRef.current && !popupRef.current.contains(e.target)) {
        setPopupVisible(false);
      }
      if (waitlistRef.current && !waitlistRef.current.contains(e.target)) {
        // Check if the clicked element is not the calendar icon button
        const calendarButton = document.querySelector('.tb-icon-circle[aria-label="waitlist"]');
        if (!calendarButton || !calendarButton.contains(e.target)) {
          setWaitlistVisible(false);
        }
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const [quickPopupOpen, setQuickPopupOpen] = useState(false);

  const currentHour = currentTime.getHours();
  const currentMinute = currentTime.getMinutes();
  const currentTimeStr = `${currentHour < 10 ? "0" + currentHour : currentHour}:${
    currentMinute < 10 ? "0" + currentMinute : currentMinute
  }`;

  // Calculate current time position for 15-minute intervals (24-hour format)
  const currentTimePosition = (currentHour * 4 + Math.floor(currentMinute / 15)) * 15;

  // Format selected date for display
  const formatSelectedDate = (date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];

    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];

    return `${dayName} ${day} ${month}`;
  };

  // Handle calendar date selection
  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setCalendarVisible(false);
    if (staffList.length > 0) {
      fetchBookings(date);
    }
  };

  // Handle date navigation
  const navigateDate = (direction) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(selectedDate.getDate() + direction);
    setSelectedDate(newDate);
    if (staffList.length > 0) {
      fetchBookings(newDate);
    }
  };

  // Handle Today button click
  const handleTodayClick = () => {
    const today = new Date();
    setSelectedDate(today);
    setCurrentTime(today);
    if (staffList.length > 0) {
      fetchBookings(today);
    }
  };

  const handleCellClick = (staffIndex, timeIndex, e) => {
    const key = `${staffIndex}-${timeIndex}`;
    const appointment = appointments[key];
    const rect = e.target.getBoundingClientRect();
    const time = timeSlots[timeIndex].time;

    setPopupData({
      key,
      x: rect.left + window.scrollX,
      y: rect.top + window.scrollY,
      time, // 👈 include time string like "02:30"
      clientName: appointment?.clientName || "",
      service: appointment?.service || "",
      paymentMethod: appointment?.paymentMethod || "",
      staffIndex,
    });

    setPopupVisible(true);
    setHoverTooltip({ visible: false, x: 0, y: 0, content: null });
  };

  // Handle cell hover to show booking details
  const handleCellHover = (staffIndex, timeIndex, e, appointment) => {
    if (appointment && !popupVisible && !waitlistVisible) {
      const rect = e.currentTarget.getBoundingClientRect();
      const staff = staffList[staffIndex];
      const timeSlot = timeSlots[timeIndex];

      const specificDetails = {
        clientName: appointment.clientName,
        service: appointment.service,
        paymentMethod: appointment.paymentMethod,
        staff: staff?.name || 'Unknown Staff',
        time: timeSlot.time,
        phone: appointment.phone,
        duration: calculateDuration(appointment.startTime, appointment.endTime),
        price: `AED ${appointment.price || 0}`,
        status: appointment.status,
        bookingNumber: appointment.bookingNumber,
        clientEmail: appointment.clientEmail,
        staffIndex,
        timeIndex,
        key: `${staffIndex}-${timeIndex}`,
      };

      // Clear any existing timeout
      if (window.tooltipTimeout) {
        clearTimeout(window.tooltipTimeout);
      }

      // Set a small delay to prevent flickering
      window.tooltipTimeout = setTimeout(() => {
      setHoverTooltip({
        visible: true,
        x: rect.left + window.scrollX + rect.width / 2,
        y: rect.top + window.scrollY - 10,
        content: specificDetails,
      });
      }, 150);
    }
  };

  // Helper function to calculate duration
  const calculateDuration = (startTime, endTime) => {
    if (!startTime || !endTime) return 'N/A';
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffMinutes = Math.floor((end - start) / (1000 * 60));
    if (diffMinutes >= 60) {
      const hours = Math.floor(diffMinutes / 60);
      const minutes = diffMinutes % 60;
      return minutes > 0 ? `${hours}h ${minutes}min` : `${hours}h`;
    }
    return `${diffMinutes}min`;
  };

  const handleCellLeave = () => {
    // Clear any pending timeout
    if (window.tooltipTimeout) {
      clearTimeout(window.tooltipTimeout);
    }
    
    // Set a small delay before hiding to prevent flickering when moving between cells
    window.tooltipHideTimeout = setTimeout(() => {
    setHoverTooltip({ visible: false, x: 0, y: 0, content: null });
    }, 150);
  };

  const handleSave = () => {
    const { key, clientName, service, paymentMethod } = popupData;
    if (clientName && service && paymentMethod) {
      setAppointments((prev) => ({
        ...prev,
        [key]: {
          clientName,
          service,
          paymentMethod,
        },
      }));
      setPopupVisible(false);
    }
  };

  const handleRefresh = () => {
    console.log("Refreshed");
    setCurrentTime(new Date());
  };

  const handleViewSelect = (mode) => {
    setViewMode(mode);
    setShowViewDropdown(false);
  };

  // Filter staff list based on selection
  const visibleStaff = staffList.filter((_, index) =>
    selectedStaff.includes(index)
  );

  // Step 1: Fetch services
  // Step 1: Fetch services
  const fetchBookingServices = async () => {
    setBookingLoading(true);
    setBookingError(null);
    try {
      const res = await fetch(`${Base_url}/bookings/services`);
      const data = await res.json();
      if (res.ok) {
        setBookingServices(data.data?.services || []);
      } else {
        throw new Error(data.message || 'Failed to fetch services');
      }
    } catch (err) {
      setBookingError('Failed to fetch services: ' + err.message);
    } finally {
      setBookingLoading(false);
    }
  };

  // Step 2: Fetch professionals for selected service and date
  const fetchBookingProfessionals = async (serviceId, date) => {
    setBookingLoading(true);
    setBookingError(null);
    try {
      const res = await fetch(`${Base_url}/bookings/professionals?service=${serviceId}&date=${date.toISOString().slice(0,10)}`);
      const data = await res.json();
      if (res.ok) {
        setBookingProfessionals(data.data?.professionals || []);
      } else {
        throw new Error(data.message || 'Failed to fetch professionals');
      }
    } catch (err) {
      setBookingError('Failed to fetch professionals: ' + err.message);
    } finally {
      setBookingLoading(false);
    }
  };

  // Step 3: Fetch time slots for selected professional
  const fetchBookingTimeSlots = async (employeeId, serviceId, date) => {
    setBookingLoading(true);
    setBookingError(null);
    try {
      const res = await fetch(`${Base_url}/bookings/time-slots?employeeId=${employeeId}&serviceId=${serviceId}&date=${date.toISOString().slice(0,10)}`);
      const data = await res.json();
      if (res.ok) {
        setBookingTimeSlots(data.data?.timeSlots || []);
      } else {
        throw new Error(data.message || 'Failed to fetch time slots');
      }
    } catch (err) {
      setBookingError('Failed to fetch time slots: ' + err.message);
    } finally {
      setBookingLoading(false);
    }
  };

  // Step 4: Create booking
  const handleCreateBooking = async () => {
    setBookingLoading(true);
    setBookingError(null);
    setBookingSuccess(null);
    try {
      const token = localStorage.getItem('token');
      
      let clientData;
      
      // If existing client is selected, use their data
      if (selectedExistingClient) {
        clientData = {
          firstName: selectedExistingClient.firstName,
          lastName: selectedExistingClient.lastName,
          email: selectedExistingClient.email,
          phone: selectedExistingClient.phone
        };
      } else {
        // Prepare client data for new client
        const nameString = clientInfo.name ? clientInfo.name.trim() : '';
        if (!nameString) {
          setBookingError('Client name is required.');
          setBookingLoading(false);
          return;
        }
        const [firstName, ...rest] = nameString.split(' ');
        const lastName = rest.join(' ') || '';
        clientData = {
          firstName,
          lastName,
          email: clientInfo.email.trim(),
          phone: clientInfo.phone.trim()
        };
      }

      const bookingPayload = {
        services: [
          {
            service: selectedService._id,
            employee: selectedProfessional._id,
            duration: selectedService.duration,
            price: selectedService.price,
            startTime: selectedTimeSlot.startTime,
            endTime: selectedTimeSlot.endTime,
          },
        ],
        appointmentDate: selectedTimeSlot.startTime,
        finalAmount: selectedService.price,
        totalDuration: selectedService.duration,
        notes: '',
        paymentMethod,
        client: clientData,
      };

      // Debug: log payload to be sent
      console.log('Booking payload:', bookingPayload);
      
      const res = await fetch(`${Base_url}/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(bookingPayload),
      });
      const data = await res.json();

      // Debug: log response data
      console.log('Booking creation response:', data);

      if (!res.ok) throw new Error(data.message || 'Booking failed');
      
      const clientName = selectedExistingClient 
        ? `${selectedExistingClient.firstName} ${selectedExistingClient.lastName}`
        : clientData.firstName;
      
      setBookingSuccess(`Booking created successfully for ${clientName}!`);
      
      // Refresh calendar data after successful booking
      setTimeout(() => {
        setBookingModalOpen(false);
        fetchBookings(selectedDate); // Refresh the calendar
        fetchWaitlistBookings(); // Refresh the waitlist
      }, 2000);
    } catch (err) {
      setBookingError(err.message);
    } finally {
      setBookingLoading(false);
    }
  };

  // Open booking modal and fetch services
  const openBookingModal = () => {
    setBookingModalOpen(true);
    setBookingStep(1);
    setSelectedService(null);
    setSelectedProfessional(null);
    setSelectedTimeSlot(null);
    setClientInfo({ name: '', email: '', phone: '' });
    setPaymentMethod('cash');
    setBookingSuccess(null);
    setBookingError(null);
    setBookingServices([]);
    setBookingProfessionals([]);
    setBookingTimeSlots([]);
    setSelectedExistingClient(null);
    setClientSearchQuery('');
    setClientSearchResults([]);
    setShowClientSearch(false);
    setIsAddingNewClient(false);
    fetchBookingServices();
    fetchExistingClients(); // Fetch existing clients when opening modal
  };

  // Booking modal UI with luxurious styling and step indicators
  const renderBookingModal = () => (
    <div className="modern-booking-modal">
      <div className="booking-modal-overlay booking-modal-fade-in">
        <div className="booking-modal booking-modal-animate-in">
          <button className="booking-modal-close" onClick={() => setBookingModalOpen(false)}>×</button>
          <h2>✨ New Appointment ✨</h2>
          
          {/* Step Indicator */}
          <div className="step-indicator">
            <div className={`step-dot ${bookingStep >= 1 ? 'active' : ''} ${bookingStep > 1 ? 'completed' : ''}`}></div>
            <div className={`step-connector ${bookingStep > 1 ? 'active' : ''}`}></div>
            <div className={`step-dot ${bookingStep >= 2 ? 'active' : ''} ${bookingStep > 2 ? 'completed' : ''}`}></div>
            <div className={`step-connector ${bookingStep > 2 ? 'active' : ''}`}></div>
            <div className={`step-dot ${bookingStep >= 3 ? 'active' : ''} ${bookingStep > 3 ? 'completed' : ''}`}></div>
            <div className={`step-connector ${bookingStep > 3 ? 'active' : ''}`}></div>
            <div className={`step-dot ${bookingStep >= 4 ? 'active' : ''} ${bookingStep > 4 ? 'completed' : ''}`}></div>
            <div className={`step-connector ${bookingStep > 4 ? 'active' : ''}`}></div>
            <div className={`step-dot ${bookingStep >= 5 ? 'active' : ''}`}></div>
          </div>

          {bookingError && <div className="booking-modal-error">{bookingError}</div>}
          {bookingLoading && <div className="booking-modal-loading">Creating your perfect appointment...</div>}
          {bookingStep === 1 && (
            <>
              <h3>💆‍♀️ Select Your Service</h3>
              <div className="booking-modal-list">
                {bookingServices.map(service => (
                  <button key={service._id} className={`booking-modal-list-item${selectedService && selectedService._id === service._id ? ' selected' : ''}`} onClick={() => { setSelectedService(service); setBookingStep(2); fetchBookingProfessionals(service._id, selectedDate); }}>
                    <div className="booking-modal-item-name">{service.name}</div>
                    <div className="booking-modal-list-desc">{service.duration} minutes • AED {service.price}</div>
                  </button>
                ))}
              </div>
            </>
          )}
          {bookingStep === 2 && (
            <>
              <h3>👨‍⚕️ Choose Your Professional</h3>
              <div className="booking-modal-list">
                {bookingProfessionals.map(prof => (
                  <button key={prof._id} className={`booking-modal-list-item${selectedProfessional && selectedProfessional._id === prof._id ? ' selected' : ''}`} onClick={() => { setSelectedProfessional(prof); setBookingStep(3); fetchBookingTimeSlots(prof._id, selectedService._id, selectedDate); }}>
                    <div className="booking-modal-item-name">{prof.user.firstName} {prof.user.lastName}</div>
                    <div className="booking-modal-list-desc">{prof.position} • Expert in {selectedService?.name}</div>
                  </button>
                ))}
              </div>
              <div className="booking-modal-actions">
                <button className="booking-modal-back" onClick={() => setBookingStep(1)}>← Back</button>
              </div>
            </>
          )}
          {bookingStep === 3 && (
            <>
              <h3>🕐 Pick Your Perfect Time</h3>
              <div className="booking-modal-list">
                {bookingTimeSlots.filter(slot => slot.available).map(slot => (
                  <button key={slot.startTime} className={`booking-modal-list-item${selectedTimeSlot && selectedTimeSlot.startTime === slot.startTime ? ' selected' : ''}`} onClick={() => { setSelectedTimeSlot(slot); setBookingStep(4); }}>
                    <div className="booking-modal-item-name">
                      {new Date(slot.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(slot.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                    <div className="booking-modal-list-desc">
                      {selectedService?.duration} minutes with {selectedProfessional?.user?.firstName}
                    </div>
                  </button>
                ))}
              </div>
              <div className="booking-modal-actions">
                <button className="booking-modal-back" onClick={() => setBookingStep(2)}>← Back</button>
              </div>
            </>
          )}
          {bookingStep === 4 && (
            <>
              <h3>👤 Client Information</h3>
              
              {/* Client Search Section */}
              <div className="client-search-section">
                <div className="client-search-header">
                  <h4>Search Existing Client</h4>
                  {selectedExistingClient && (
                    <button 
                      className="clear-client-btn" 
                      onClick={clearClientSelection}
                    >
                      Clear Selection
                    </button>
                  )}
                </div>
                
                {!selectedExistingClient && !isAddingNewClient && (
                  <div className="client-search-input">
                    <input
                      type="text"
                      placeholder="Search by name, email, or phone..."
                      value={clientSearchQuery}
                      onChange={handleClientSearchChange}
                      onFocus={() => {
                        setShowClientSearch(true);
                        searchClients(clientSearchQuery); // Trigger search when focused
                      }}
                      onBlur={() => {
                        // Delay hiding to allow clicking on results
                        setTimeout(() => setShowClientSearch(false), 200);
                      }}
                    />
                    {showClientSearch && clientSearchResults.length > 0 && (
                      <div className="client-search-results">
                        {clientSearchResults.map(client => (
                          <div 
                            key={client._id} 
                            className="client-search-result"
                            onClick={() => selectExistingClient(client)}
                          >
                            <div className="client-result-avatar">
                              {(client.firstName?.[0] || '') + (client.lastName?.[0] || '')}
                            </div>
                            <div className="client-result-info">
                              <div className="client-result-name">
                                {client.firstName} {client.lastName}
                              </div>
                              <div className="client-result-contact">
                                {client.email} • {client.phone}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {showClientSearch && clientSearchQuery && clientSearchResults.length === 0 && (
                      <div className="client-search-no-results">
                        <p>No clients found</p>
                        <button 
                          className="add-new-client-btn"
                          onClick={addNewClient}
                        >
                          Add New Client
                        </button>
                      </div>
                    )}
                    
                    {!showClientSearch && (
                      <button 
                        className="add-new-client-btn"
                        onClick={addNewClient}
                      >
                        + Add New Client
                      </button>
                    )}
                  </div>
                )}
                
                {/* Selected Client Display */}
                {selectedExistingClient && (
                  <div className="selected-client-display">
                    <div className="selected-client-avatar">
                      {(selectedExistingClient.firstName?.[0] || '') + (selectedExistingClient.lastName?.[0] || '')}
                    </div>
                    <div className="selected-client-info">
                      <div className="selected-client-name">
                        {selectedExistingClient.firstName} {selectedExistingClient.lastName}
                      </div>
                      <div className="selected-client-contact">
                        {selectedExistingClient.email} • {selectedExistingClient.phone}
                      </div>
                    </div>
                    <div className="selected-client-badge">
                      Existing Client
                    </div>
                  </div>
                )}
                
                {/* New Client Form */}
                {isAddingNewClient && (
                  <div className="new-client-form">
                    <div className="new-client-header">
                      <h4>Add New Client</h4>
                      <button 
                        className="back-to-search-btn"
                        onClick={() => {
                          setIsAddingNewClient(false);
                          setShowClientSearch(true);
                        }}
                      >
                        ← Back to Search
                      </button>
                    </div>
                    <div className="booking-modal-form">
                      <div className="form-group">
                        <label htmlFor="clientName">Client Name *</label>
                        <input 
                          id="clientName"
                          type="text" 
                          placeholder="Enter client's full name" 
                          value={clientInfo.name} 
                          onChange={e => setClientInfo(f => ({ ...f, name: e.target.value }))} 
                          required 
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="clientEmail">Email Address *</label>
                        <input 
                          id="clientEmail"
                          type="email" 
                          placeholder="Enter client's email address" 
                          value={clientInfo.email} 
                          onChange={e => setClientInfo(f => ({ ...f, email: e.target.value }))} 
                          required 
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="clientPhone">Phone Number *</label>
                        <input 
                          id="clientPhone"
                          type="tel" 
                          placeholder="Enter client's phone number" 
                          value={clientInfo.phone} 
                          onChange={e => setClientInfo(f => ({ ...f, phone: e.target.value }))} 
                          required 
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="booking-modal-actions">
                <button 
                  className="booking-modal-next" 
                  onClick={() => setBookingStep(5)}
                  disabled={
                    !selectedExistingClient && 
                    (!clientInfo.name.trim() || !clientInfo.email.trim() || !clientInfo.phone.trim())
                  }
                >
                  Continue to Payment →
                </button>
                <button className="booking-modal-back" onClick={() => setBookingStep(3)}>← Back</button>
              </div>
            </>
          )}
          {bookingStep === 5 && (
            <>
              <h3>💳 Payment & Final Confirmation</h3>
              <div className="booking-summary">
                <div className="summary-item">
                  <span>Client:</span>
                  <span>
                    {selectedExistingClient 
                      ? `${selectedExistingClient.firstName} ${selectedExistingClient.lastName}`
                      : clientInfo.name
                    }
                    {selectedExistingClient && (
                      <span className="existing-client-indicator">✨ VIP Member</span>
                    )}
                  </span>
                </div>
                <div className="summary-item">
                  <span>📧 Email:</span>
                  <span>
                    {selectedExistingClient 
                      ? selectedExistingClient.email
                      : clientInfo.email
                    }
                  </span>
                </div>
                <div className="summary-item">
                  <span>📱 Phone:</span>
                  <span>
                    {selectedExistingClient 
                      ? selectedExistingClient.phone
                      : clientInfo.phone
                    }
                  </span>
                </div>
                <div className="summary-item">
                  <span>💆‍♀️ Service:</span>
                  <span>{selectedService?.name}</span>
                </div>
                <div className="summary-item">
                  <span>👨‍⚕️ Professional:</span>
                  <span>{selectedProfessional?.user?.firstName} {selectedProfessional?.user?.lastName}</span>
                </div>
                <div className="summary-item">
                  <span>📅 Date & Time:</span>
                  <span>
                    {selectedDate?.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })} at {' '}
                    {selectedTimeSlot ? new Date(selectedTimeSlot.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                  </span>
                </div>
                <div className="summary-item">
                  <span>⏱️ Duration:</span>
                  <span>{selectedService?.duration} minutes of luxury</span>
                </div>
                <div className="summary-item">
                  <span>💰 Investment:</span>
                  <span>AED {selectedService?.price}</span>
                </div>
              </div>
              <div className="booking-modal-form">
                <div className="form-group">
                  <label>💳 Select Payment Method:</label>
                  <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
                    {paymentMethods.map(pm => (
                      <option key={pm.value} value={pm.value}>{pm.label}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="booking-modal-actions">
                <button 
                  className="booking-modal-confirm" 
                  onClick={handleCreateBooking}
                  disabled={bookingLoading}
                >
                  {bookingLoading ? '✨ Creating Your Luxury Experience...' : '🌟 Confirm Booking 🌟'}
                </button>
                <button className="booking-modal-back" onClick={() => setBookingStep(4)}>← Back</button>
              </div>
            </>
          )}
          {bookingSuccess && <div className="booking-modal-success">{bookingSuccess}</div>}
        </div>
      </div>
    </div>
  );

  // Fetch staff list from backend
  const fetchStaffList = async () => {
    setStaffLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${Base_url}/employees`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (res.ok) {
        const formattedStaff = data.data.employees.map((employee, index) => ({
          id: employee._id,
          name: `${employee.user?.firstName || ''} ${employee.user?.lastName || ''}`.trim(),
          avatar: generateAvatar(employee.user?.firstName, employee.user?.lastName),
          color: staffColors[index % staffColors.length],
          profileImage: employee.user?.profileImage || null,
          position: employee.position || 'Staff',
          employeeId: employee.employeeId,
          user: employee.user,
          isActive: employee.isActive,
        }));
        setStaffList(formattedStaff);
        setSelectedStaff(formattedStaff.map((_, index) => index)); // Select all by default
      } else {
        console.error('Failed to fetch staff:', data.message);
      }
    } catch (error) {
      console.error('Error fetching staff:', error);
    } finally {
      setStaffLoading(false);
    }
  };

  // Fetch bookings for waitlist
  const fetchWaitlistBookings = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${Base_url}/bookings/admin/all`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (res.ok) {
        const allBookings = data.data.bookings;
        const now = new Date();
        
        const categorizedBookings = {
          upcoming: allBookings.filter(booking => {
            const bookingDate = new Date(booking.appointmentDate);
            return bookingDate >= now && ['pending', 'confirmed'].includes(booking.status);
          }),
          completed: allBookings.filter(booking => {
            const bookingDate = new Date(booking.appointmentDate);
            return bookingDate < now || booking.status === 'completed';
          }),
          booked: allBookings.filter(booking => 
            ['confirmed', 'pending', 'booked'].includes(booking.status)
          )
        };
        
        setWaitlistBookings(categorizedBookings);
        console.log('Waitlist bookings updated:', categorizedBookings);
      }
    } catch (error) {
      console.error('Error fetching waitlist bookings:', error);
    }
  };

  // Fetch bookings for the calendar
  const fetchBookings = async (date) => {
    setBookingsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${Base_url}/bookings/admin/all`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (res.ok) {
        const filteredBookings = data.data.bookings.filter(booking => {
          const bookingDate = new Date(booking.appointmentDate);
          return bookingDate.toDateString() === date.toDateString();
        });
        setBookings(filteredBookings);
        processBookingsForCalendar(filteredBookings);
        
        // Also update waitlist data
        fetchWaitlistBookings();
      } else {
        console.error('Failed to fetch bookings:', data.message);
      }
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setBookingsLoading(false);
    }
  };

  // Process bookings to match calendar grid format (updated for 24-hour format)
  const processBookingsForCalendar = (bookings) => {
    const newAppointments = {};
    
    bookings.forEach(booking => {
      booking.services.forEach(service => {
        const startTime = new Date(service.startTime);
        const startHour = startTime.getHours();
        const startMinute = startTime.getMinutes();
        
        // Calculate time slot index (15-minute intervals from 00:00)
        const timeSlotIndex = startHour * 4 + Math.floor(startMinute / 15);
        
        // Find staff index
        const staffIndex = staffList.findIndex(staff => staff.id === service.employee._id);
        
        if (staffIndex !== -1 && timeSlotIndex >= 0) {
          const key = `${staffIndex}-${timeSlotIndex}`;
          const clientName = booking.client 
            ? `${booking.client.firstName || ''} ${booking.client.lastName || ''}`.trim()
            : 'Unknown Client';
          
          newAppointments[key] = {
            clientName,
            service: service.service?.name || 'Unknown Service',
            paymentMethod: booking.paymentMethod || 'Not specified',
            status: booking.status,
            bookingId: booking._id,
            startTime: service.startTime,
            endTime: service.endTime,
            price: service.price,
            phone: booking.client?.phone || booking.client?.email || 'N/A',
            employee: service.employee,
            bookingNumber: booking.bookingNumber,
            clientEmail: booking.client?.email || 'N/A',
          };
        }
      });
    });
    
    setAppointments(newAppointments);
  };

  // Initial data fetch
  useEffect(() => {
    fetchStaffList();
    fetchWaitlistBookings();
  }, []);

  // Fetch bookings when date changes or staff list is loaded
  useEffect(() => {
    if (staffList.length > 0) {
      fetchBookings(selectedDate);
    }
  }, [selectedDate, staffList]);

  // Handle calendar toggle
  const toggleCalendar = () => {
    setCalendarVisible(!calendarVisible);
  };

  // Handle team selection toggle
  const toggleTeamSelection = () => {
    setTeamSelectionVisible(!teamSelectionVisible);
  };

  // Handle staff selection toggle
  const handleStaffToggle = (staffIndex) => {
    setSelectedStaff((prev) => {
      if (prev.includes(staffIndex)) {
        return prev.filter((index) => index !== staffIndex);
      } else {
        return [...prev, staffIndex];
      }
    });
  };

  // Fetch existing clients
  const fetchExistingClients = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${Base_url}/admin/clients`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log('Clients API response:', res);
      const data = await res.json();
      console.log('Clients API response:', data);
      if (res.ok) {
        setExistingClients(data.data?.clients || []);
        console.log('Set existing clients:', data.data?.clients || []);
      } else {
        console.error('Failed to fetch clients:', data.message);
      }
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  };

  // Search clients based on query
  const searchClients = (query) => {
    if (!query.trim()) {
      // Show all clients when search is empty but input is focused
      if (showClientSearch) {
        setClientSearchResults(existingClients.slice(0, 10)); // Limit to first 10
      } else {
        setClientSearchResults([]);
      }
      return;
    }
    
    console.log('Searching for:', query);
    console.log('Available clients:', existingClients);
    
    const filtered = existingClients.filter(client => {
      const fullName = `${client.firstName || ''} ${client.lastName || ''}`.toLowerCase();
      const email = (client.email || '').toLowerCase();
      const phone = (client.phone || '').toLowerCase();
      const searchTerm = query.toLowerCase();
      
      const matches = fullName.includes(searchTerm) || 
             email.includes(searchTerm) || 
             phone.includes(searchTerm);
      
      console.log(`Client: ${fullName} | Email: ${email} | Phone: ${phone} | Matches: ${matches}`);
      
      return matches;
    });
    
    console.log('Filtered results:', filtered);
    setClientSearchResults(filtered);
  };

  // Handle client search input change
  const handleClientSearchChange = (e) => {
    const query = e.target.value;
    setClientSearchQuery(query);
    searchClients(query);
  };

  // Select existing client
  const selectExistingClient = (client) => {
    setSelectedExistingClient(client);
    setClientInfo({
      name: `${client.firstName || ''} ${client.lastName || ''}`.trim(),
      email: client.email || '',
      phone: client.phone || ''
    });
    setClientSearchQuery('');
    setClientSearchResults([]);
    setShowClientSearch(false);
    setIsAddingNewClient(false);
  };

  // Add new client
  const addNewClient = () => {
    setSelectedExistingClient(null);
    setClientInfo({ name: '', email: '', phone: '' });
    setClientSearchQuery('');
    setClientSearchResults([]);
    setShowClientSearch(false);
    setIsAddingNewClient(true);
  };

  // Clear client selection
  const clearClientSelection = () => {
    setSelectedExistingClient(null);
    setClientInfo({ name: '', email: '', phone: '' });
    setClientSearchQuery('');
    setClientSearchResults([]);
    setShowClientSearch(false);
    setIsAddingNewClient(false);
  };

  return (
    <div>
      <div className="tb-container">
        <div className="tb-left">
          <button className="tb-btn" onClick={handleTodayClick}>
            Today
          </button>
          <div className="tb-date-box">
            <button className="tb-icon-btn" onClick={() => navigateDate(-1)}>
              <ChevronLeft size={18} />
            </button>
            <span
              className="tb-date-text"
              onClick={toggleCalendar}
              style={{ cursor: "pointer" }}
            >
              {formatSelectedDate(selectedDate)}
            </span>
            <button className="tb-icon-btn" onClick={() => navigateDate(1)}>
              <ChevronRight size={18} />
            </button>
          </div>
          <button className="tb-icon-circle" onClick={toggleTeamSelection}>
            <Users size={18} />
          </button>
        </div>

        <div className="tb-right">
          <button
            className="tb-icon-circle"
            onClick={() => setWaitlistVisible(!waitlistVisible)}
            aria-label="waitlist"
          >
            <CalendarDays size={18} />
          </button>

          <div className="tb-dropdown">
            <div className="tb-btn-group">
              <button className="tb-icon-part" onClick={handleRefresh}>
                <RotateCcw size={16} />
              </button>
              <div className="tb-divider" />
              <button
                className="tb-text-part"
                onClick={() => setShowViewDropdown(!showViewDropdown)}
              >
                {viewMode}
                <span className="tb-caret-down">▾</span>
              </button>
            </div>
            {showViewDropdown && (
              <div className="tb-dropdown-menu">
                <div
                  className="tb-dropdown-item"
                  onClick={() => handleViewSelect("Day")}
                >
                  Day
                </div>
                <div
                  className="tb-dropdown-item"
                  onClick={() => handleViewSelect("Week")}
                >
                  Week
                </div>
                <div
                  className="tb-dropdown-item"
                  onClick={() => handleViewSelect("Month")}
                >
                  Month
                </div>
              </div>
            )}
          </div>

          <div className="tb-dropdown ds-add-dropdown-container">
            <button
              className="tb-btn tb-add-btn"
              onClick={openBookingModal}
            >
              Add <span className="tb-caret-down">▾</span>
            </button>
            {addDropdownOpen && (
              <div className="ds-add-dropdown">
                <div className="ds-dropdown-item">
                  <Calendar size={16} />
                  <span>Appointment</span>
                </div>
                <div className="ds-dropdown-item">
                  <Users size={16} />
                  <span>Group appointment</span>
                </div>
                <div className="ds-dropdown-item">
                  <XSquare size={16} />
                  <span>Blocked time</span>
                </div>
                <div className="ds-dropdown-item">
                  <Tag size={16} />
                  <span>Sale</span>
                </div>
                <div className="ds-dropdown-item">
                  <DollarSign size={16} />
                  <span>Quick payment</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="scheduler-container">
        <div className="scheduler-header-wrapper">
          <div className="time-column-placeholder"></div>
          <div className="scheduler-header">
            {staffLoading ? (
              <div className="scheduler-loading">Loading staff...</div>
            ) : (
              visibleStaff.map((staff, index) => {
              const originalIndex = staffList.findIndex(
                  (s) => s.id === staff.id
              );
              return (
                  <div className="scheduler-header-col" key={staff.id}>
                  <div className="scheduler-avatar">
                    {staff.profileImage ? (
                      <img
                        src={staff.profileImage}
                        alt={staff.name}
                        className="avatar-image"
                      />
                    ) : (
                      <div
                        className="avatar-placeholder"
                        style={{
                          backgroundColor: staff.color,
                          borderColor: staff.color,
                        }}
                      >
                        <span className="avatar-text">{staff.avatar}</span>
                      </div>
                    )}
                  </div>
                  <div className="scheduler-name">{staff.name}</div>
                    <div className="scheduler-position">{staff.position}</div>
                </div>
              );
              })
            )}
          </div>
        </div>

        <div className="scheduler-grid">
          <div className="time-column">
            {timeSlots.map((slot, i) => (
              <div
                key={i}
                className={`time-slot ${
                  slot.isHourStart ? "hour-start" : "quarter-hour"
                }`}
              >
                {slot.isHourStart ? slot.time : ""}
              </div>
            ))}
          </div>

          <div className="grid-columns">
            {visibleStaff.map((staff, colIdx) => {
              const originalIndex = staffList.findIndex(
                (s) => s.id === staff.id
              );
              return (
                <div key={staff.id} className="grid-col">
                  {timeSlots.map((slot, rowIdx) => {
                    const key = `${originalIndex}-${rowIdx}`;
                    const hasAppointment = appointments[key];
                    console.log('hasAppointment:', key, hasAppointment);
                    return (
                      <div
                        key={rowIdx}
                        className={`grid-cell ${
                          slot.isHourStart
                            ? "hour-start-cell"
                            : "quarter-hour-cell"
                        }`}
                        style={{
                          backgroundColor: hasAppointment
                            ? staff.color
                            : "#fff",
                          border: hasAppointment
                            ? `2px solid ${staff.color}`
                            : slot.isHourStart
                            ? "1px solid #f1f1f1"
                            : "1px solid #f1f1f1",
                        }}
                        onClick={(e) =>
                          handleCellClick(originalIndex, rowIdx, e)
                        }
                        onMouseEnter={(e) =>
                          handleCellHover(
                            originalIndex,
                            rowIdx,
                            e,
                            hasAppointment
                          )
                        }
                        onMouseLeave={handleCellLeave}
                      >
                        
                        {hasAppointment && (
                          <div className="appointment-text">
                            {hasAppointment.clientName} -{" "}
                            {hasAppointment.service}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>

          {/* Current time line - now works for 24-hour format */}
            <div
              className="current-time-line"
              style={{ top: `${currentTimePosition}px` }}
            >
              <div className="time-badge">{currentTimeStr}</div>
            </div>
        </div>

        {/* Custom Calendar Component */}
        <CustomCalendar
          isVisible={calendarVisible}
          onClose={() => setCalendarVisible(false)}
          onDateSelect={handleDateSelect}
          selectedDate={selectedDate}
        />

        {/* Team Selection Component */}
        <TeamSelection
          isVisible={teamSelectionVisible}
          onClose={() => setTeamSelectionVisible(false)}
          staffList={staffList}
          selectedStaff={selectedStaff}
          onStaffToggle={handleStaffToggle}
        />

        {/* Hover Tooltip */}
        {hoverTooltip.visible && hoverTooltip.content && !popupVisible && !waitlistVisible && (
          <div
            className="hover-tooltip-card"
            ref={tooltipRef}
            style={{
              top: hoverTooltip.y,
              left: hoverTooltip.x,
              transform: 'translateX(-50%)',
              zIndex: 1002,
            }}
            onMouseEnter={() => {
              // Clear any pending hide timeout when mouse enters tooltip
              if (window.tooltipHideTimeout) {
                clearTimeout(window.tooltipHideTimeout);
              }
            }}
            onMouseLeave={() => {
              // Hide tooltip when mouse leaves
              setHoverTooltip({ visible: false, x: 0, y: 0, content: null });
            }}
          >
            <div className="tooltip-header">
              <span className="tooltip-time">
                {hoverTooltip.content.time}
              </span>
              <span className={`tooltip-status status-${hoverTooltip.content.status}`}>
                {hoverTooltip.content.status}
              </span>
            </div>

            <div className="tooltip-user-info">
              <div className="tooltip-avatar">
                {hoverTooltip.content.clientName.split(' ').map(n => n[0]).join('').toUpperCase()}
              </div>
              <div className="tooltip-user-details">
                <div className="tooltip-client-name">
                  {hoverTooltip.content.clientName}
                </div>
                <div className="tooltip-phone">
                  {hoverTooltip.content.phone}
                </div>
              </div>
            </div>

            <div className="tooltip-service">
              <div className="tooltip-service-name">
                {hoverTooltip.content.service}
              </div>
              <div className="tooltip-staff-duration">
                {hoverTooltip.content.staff} • {hoverTooltip.content.duration}
              </div>
            </div>

            <div className="tooltip-price">
              <div className="tooltip-discounted">
                {hoverTooltip.content.price}
              </div>
              <div className="tooltip-payment">
                {hoverTooltip.content.paymentMethod}
              </div>
            </div>

            <div className="tooltip-footer">
              <div className="tooltip-booking-id">
                #{hoverTooltip.content.bookingNumber || 'N/A'}
              </div>
              <div className="tooltip-calendar-icon">📅</div>
            </div>
          </div>
        )}

        {waitlistVisible && (
          <div className="waitlist-popup" ref={waitlistRef}>
            <div className="waitlist-header">
              <h2>Bookings Overview</h2>
              <button 
                className="waitlist-close"
                onClick={() => setWaitlistVisible(false)}
              >
                ×
              </button>
            </div>

            <div className="waitlist-tabs">
              {[
                { key: "upcoming", label: "Upcoming", count: waitlistBookings.upcoming?.length || 0 },
                { key: "completed", label: "Completed", count: waitlistBookings.completed?.length || 0 },
                { key: "booked", label: "Booked", count: waitlistBookings.booked?.length || 0 }
              ].map((tab) => (
                <div
                  key={tab.key}
                  className={`waitlist-tab ${
                    activeWaitlistTab === tab.key ? "active" : ""
                  }`}
                  onClick={() => setActiveWaitlistTab(tab.key)}
                >
                  {tab.label} <span className="count">{tab.count}</span>
                </div>
              ))}
            </div>

            <div className="waitlist-content">
              {waitlistBookings[activeWaitlistTab]?.length > 0 ? (
                <div className="waitlist-bookings-list">
                  {waitlistBookings[activeWaitlistTab].map((booking) => (
                    <div key={booking._id} className="waitlist-booking-item">
                      <div className="booking-item-header">
                        <div className="booking-client-info">
                          <div className="booking-client-avatar">
                            {booking.client?.firstName?.[0]}{booking.client?.lastName?.[0]}
                          </div>
                          <div className="booking-client-details">
                            <div className="booking-client-name">
                              {booking.client?.firstName} {booking.client?.lastName}
                            </div>
                            <div className="booking-client-contact">
                              {booking.client?.email || booking.client?.phone}
                            </div>
                          </div>
                        </div>
                        <div className="booking-status">
                          <span className={`status-badge status-${booking.status}`}>
                            {booking.status}
                          </span>
                        </div>
                      </div>
                      
                      <div className="booking-item-details">
                        <div className="booking-service-info">
                          {booking.services.map((service, index) => (
                            <div key={index} className="service-item">
                              <span className="service-name">{service.service?.name}</span>
                              <span className="service-employee">
                                with {service.employee?.user?.firstName} {service.employee?.user?.lastName}
                              </span>
                            </div>
                          ))}
                        </div>
                        
                        <div className="booking-time-info">
                          <div className="booking-date">
                            {new Date(booking.appointmentDate).toLocaleDateString()}
                          </div>
                          <div className="booking-time">
                            {booking.services.map((service, index) => (
                              <span key={index}>
                                {new Date(service.startTime).toLocaleTimeString([], { 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                                {index < booking.services.length - 1 && ', '}
                              </span>
                            ))}
                          </div>
                        </div>
                        
                        <div className="booking-payment-info">
                          <span className="booking-amount">AED {booking.totalAmount}</span>
                          <span className="booking-payment-method">{booking.paymentMethod}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
            <div className="waitlist-empty">
                  <div className="waitlist-icon">📅</div>
              <p className="waitlist-title">
                    No {activeWaitlistTab.toLowerCase()} bookings
              </p>
              <p className="waitlist-subtext">
                    You don't have any {activeWaitlistTab.toLowerCase()} bookings at the moment.
              </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Edit Popup */}
        {popupVisible && (
          <div
            className="popup-reminder"
            ref={popupRef}
            style={{ top: popupData.y + 10, left: popupData.x + 10 }}
          >
            <h4>Appointment</h4>

            <div className="quick-actions-box">
              <div className="quick-actions-time">
                {popupData.time || "Select time"}
              </div>

              <button className="quick-action-button" onClick={() => { setPopupVisible(false); openBookingModal(); }}>
                <Calendar size={14} />
                Add appointment
              </button>

              {/* <button className="quick-action-button">
                <Users size={14} />
                Add group appointment
              </button>

              <button className="quick-action-button">
                <XSquare size={14} />
                Add blocked time
              </button> */}

             
            </div>
          </div>
        )}
      </div>
      {bookingModalOpen && renderBookingModal()}
    </div>
  );
};

export default Scheduler;

